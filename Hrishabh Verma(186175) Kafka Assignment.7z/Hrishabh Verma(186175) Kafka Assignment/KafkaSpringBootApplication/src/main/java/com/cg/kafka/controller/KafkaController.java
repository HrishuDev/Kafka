package com.cg.kafka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.kafka.bean.UserModel;


@RestController
@RequestMapping(value = "/requestuser")
public class KafkaController 
{

	@Autowired
	 KafkaTemplate<String, UserModel> KafkaJsontemplate;
	 String TOPIC_NAME = "usermodel";
	 
	@PostMapping(value = "/getsend",consumes = {"application/json"},produces = {"application/json"})
	public String producer(@RequestBody UserModel user) 
	{
		KafkaJsontemplate.send(TOPIC_NAME, new UserModel(user.getFirstName(),user.getLastName(),user.getAddress1(),user.getAddress2(),user.getShoppingInterest()));
		System.out.println(user.getFirstName());
		//producer.sendmodel1(user);
		return "Message produced to usermodel";
	}

}
