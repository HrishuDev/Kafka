package com.cg.kafkaconsumer.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.kafkaconsumer.bean.KafkaUser;

@RestController
public class KafkaconsumerController {

	List<String> message = new ArrayList<>();

	@GetMapping("/messageconsumer")
	public List<String> consume() {
		return message;
	}

	@GetMapping("/consumeJsonMessage")
	public List<String> consumeJsonMessage() {
		return message;
	}

	@KafkaListener(groupId = "topic1", topics = "usermodel", containerFactory = "kafkaListenerContainerFactory")
	public List<String> getMsgFromTopic(String data) {
		System.out.println("Published message: " + data);
		message.add(data);
		return message;
	}
	
}