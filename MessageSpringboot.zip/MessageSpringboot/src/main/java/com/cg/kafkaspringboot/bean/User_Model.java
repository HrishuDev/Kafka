package com.cg.kafkaspringboot.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
@SequenceGenerator(name="Sequenceno", initialValue=1, allocationSize=1)
@Table(name="usermodel")
public class User_Model 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="Sequenceno")
	private int Sr_no;
	
	@NotEmpty(message="Cannot Be Empty")
	@Pattern(regexp = "^[\\p{L} .'-]+$", message = "Name Can Have Only Alphabets & Spaces")
	private String Firstname;
	
	@NotEmpty(message="Cannot Be Empty")
	@Pattern(regexp = "^[\\p{L} .'-]+$", message = "Name Can Have Only Alphabets & Spaces")
	private String Lastname;
	
	@NotEmpty(message="Cannot Be Empty")
	@Pattern(regexp = "^\\d+\\s[A-z]+\\s[A-z]+")
	private String Address;
	
	@NotEmpty(message="Cannot Be Empty")
	private String ShopInterest;
	
	@NotEmpty(message="Cannot Be Empty")
	@Pattern(regexp = "^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$", message = "Enter A Valid Mobile Number")
	private String PAN;

	public int getSr_no() {
		return Sr_no;
	}

	public void setSr_no(int sr_no) {
		Sr_no = sr_no;
	}

	public String getFirstname() {
		return Firstname;
	}

	public void setFirstname(String firstname) {
		Firstname = firstname;
	}

	public String getLastname() {
		return Lastname;
	}

	public void setLastname(String lastname) {
		Lastname = lastname;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getShopInterest() {
		return ShopInterest;
	}

	public void setShopInterest(String shopInterest) {
		ShopInterest = shopInterest;
	}

	public String getPAN() {
		return PAN;
	}

	public void setPAN(String pAN) {
		PAN = pAN;
	}

	@Override
	public String toString() {
		return "User_Model [Sr_no=" + Sr_no + ", Firstname=" + Firstname + ", Lastname=" + Lastname + ", Address="
				+ Address + ", ShopInterest=" + ShopInterest + ", PAN=" + PAN + "]";
	}
	
	
}
