package com.cg.Springbatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBatchProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBatchProjectApplication.class, args);
	}
}
