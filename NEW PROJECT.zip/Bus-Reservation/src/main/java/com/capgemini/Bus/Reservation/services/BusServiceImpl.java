package com.capgemini.Bus.Reservation.services;

import java.util.List;

import com.capgemini.Bus.Reservation.dao.BusOperationDaoImpl;
import com.capgemini.Bus.Reservation.entity.Bus;
import com.capgemini.Bus.Reservation.entity.User;

public class BusServiceImpl implements BusService{

	BusOperationDaoImpl dao= new BusOperationDaoImpl();
	@Override
	public List<Bus> findallBuses() {
		// TODO Auto-generated method stub
		return dao.findallBuses();
	}

	@Override
	public List<User> findallUsers() {
		// TODO Auto-generated method stub
		return dao.findallUsers();
	}

	@Override
	public Bus findById(int theId) {
		// TODO Auto-generated method stub
		return dao.findById(theId);
	}

	@Override
	public void save(Bus theBus) {
		// TODO Auto-generated method stub
		dao.save(theBus);
	}

	@Override
	public void deletebyId(int theId) {
		// TODO Auto-generated method stub
		dao.deletebyId(theId);
	}

}
