package com.capgemini.Bus.Reservation.entity;

public class Trasactions {

}
